<?php
/**
 * The template for displaying single Album Gallery posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 */

get_header();

$data = get_option('mygallery_options');
$is_sidebar = !empty($data['myg_ap_show_sidebar'])?$data['myg_ap_show_sidebar']:'yes';
$sidebar_pos = !empty($data['myg_ap_sidebar_pos'])?$data['myg_ap_sidebar_pos']:'left';
$sidebar = !empty($data['myg_ap_sidebar'])?$data['myg_ap_sidebar']:'';
$load_type = !empty($data['myg_algal_load_type'])?$data['myg_algal_load_type']:'tosingle';
$album_type = !empty($data['myg_ap_album_style'])?$data['myg_ap_album_style']:'modern';
?>

<main id="site-content" role="main">

	<div class="myg_container myg_archive_page">
        <div class="myg_row">
        	<?php if($is_sidebar == 'yes' && $sidebar_pos == 'left' && is_active_sidebar($sidebar)): ?>
            <div class="myg-col-md-3">
                <div class="myg-left-sidebar">
                <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if ( $is_sidebar == 'yes') : ?>
            <div class="myg-col-md-9">
            <?php else: ?>
            <div class="myg-col-md-12">
            <?php endif; ?>
            
            <?php
			global $post; global $wp_query;
			$ajax_single = new mygallery_Ajax();
			
			if ( have_posts() ) {
				echo '<div class="myg_album_container myg_clearfix">';
				while ( have_posts() ) {
					the_post();
					$gallery = MyGallery::get_by_id( get_the_ID() );
					$image_ids = $gallery->attachment_ids;
					$title = esc_html( get_the_title() );
					$permalink = get_permalink(get_the_ID());
					$count = sizeof( $image_ids );
					
					if($album_type == 'basic'){
						if($count >= 1){
							$attachment1 = MyGalleryAttachment::get_by_id( $image_ids[0], 'thumbnail' );
							echo '<div class="myg_album_image_wrap">';
							echo ($load_type == 'tosingle')? '<a class="myg_album_image" href="'.$permalink.'" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">':'<div class="myg_album_image" data-event="myg_open_album_gallery" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">';
							echo '<img class="myg_album_single" src="'.$attachment1->url.'" />';
							echo ($load_type == 'tosingle')? '</a>':'</div>';
							echo '<div class="myg_album_image_count">'.$title.' ('.$count.')</div>';
							echo '</div>';
						}
					}else{
						if($count == 0){
							// Do nothing
						}elseif($count == 1){
							$attachment1 = MyGalleryAttachment::get_by_id( $image_ids[0], 'thumbnail' );
							echo '<div class="myg_album_image_wrap">';
							echo ($load_type == 'tosingle')? '<a class="myg_album_image" href="'.$permalink.'" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">':'<div class="myg_album_image" data-event="myg_open_album_gallery" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">';
							echo '<img class="myg_album_single" src="'.$attachment1->url.'" />';
							echo ($load_type == 'tosingle')? '</a>':'</div>';
							echo '<div class="myg_album_image_count">'.$title.' ('.$count.')</div>';
							echo '</div>';
						}elseif($count == 2){
							$attachment1 = MyGalleryAttachment::get_by_id( $image_ids[0], 'thumbnail' );
							$attachment2 = MyGalleryAttachment::get_by_id( $image_ids[1], 'thumbnail' );
							echo '<div class="myg_album_image_wrap">';
							echo ($load_type == 'tosingle')? '<a class="myg_album_image" href="'.$permalink.'" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">':'<div class="myg_album_image" data-event="myg_open_album_gallery" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">';
							echo '<img class="myg_album_photo1" src="'.$attachment1->url.'" />';
							echo '<img class="myg_album_photo2" src="'.$attachment2->url.'" />';
							echo ($load_type == 'tosingle')? '</a>':'</div>';
							echo '<div class="myg_album_image_count">'.$title.' ('.$count.')</div>';
							echo '</div>';
						}elseif($count > 2){
							$attachment1 = MyGalleryAttachment::get_by_id( $image_ids[0], 'thumbnail' );
							$attachment2 = MyGalleryAttachment::get_by_id( $image_ids[1], 'thumbnail' );
							$attachment3 = MyGalleryAttachment::get_by_id( $image_ids[2], 'thumbnail' );
							echo '<div class="myg_album_image_wrap">';
							echo ($load_type == 'tosingle')? '<a class="myg_album_image" href="'.$permalink.'" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">':'<div class="myg_album_image" data-event="myg_open_album_gallery" data-myg-album-id="'.get_the_ID().'" data-myg-album-type="'.$album_type.'">';
							echo '<img class="myg_album_photo1" src="'.$attachment1->url.'" />';
							echo '<img class="myg_album_photo2" src="'.$attachment2->url.'" />';
							echo '<img class="myg_album_photo3" src="'.$attachment3->url.'" />';
							echo ($load_type == 'tosingle')? '</a>':'</div>';
							echo '<div class="myg_album_image_count">'.$title.' ('.$count.')</div>';
							echo '</div>';
						}
					}
				}
				echo '</div>';
				echo mygallery_pagination($wp_query->max_num_pages, $range = 6);
			}
			?>            
            </div><!-- .col-md-9,12 -->
            <?php if ( $is_sidebar == 'yes'  && $sidebar_pos == 'right' && is_active_sidebar($sidebar) ) : ?>
            <div class="myg-col-md-3">
                <div class="myg-right-sidebar">
                <?php dynamic_sidebar( $sidebar ); ?>
                </div>
            </div>
            <?php endif; ?>
        
        </div><!-- .myg_row -->
	</div><!-- .myg_container -->
</main><!-- #site-content -->

<?php get_footer(); ?>