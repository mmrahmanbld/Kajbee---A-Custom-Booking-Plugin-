<?php
/**
 * The template for displaying single Album Gallery posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 */

get_header();
?>

    <div class="row mtb-40">       
        <?php if ( is_active_sidebar( 'kaj-left-sidebar' ) ) : ?>
        <div class="col-md-3">
            <?php dynamic_sidebar( 'kaj-left-sidebar' ); ?>
        </div>
        <?php endif; ?>
        <?php if ( is_active_sidebar( 'kaj-left-sidebar' ) && is_active_sidebar( 'kaj-right-sidebar' )) : ?>
        <div class="col-md-6">
        <?php elseif ( is_active_sidebar( 'kaj-left-sidebar' ) || is_active_sidebar( 'kaj-right-sidebar' )) : ?>
        <div class="col-md-9">
        <?php else: ?>
        <div class="col-md-12">
        <?php endif; ?>
        <?php if ( is_active_sidebar( 'kaj-top-sidebar' ) ) : ?>
        <div class="row">
            <div class="col-md-12 top-sidebar">
                <?php dynamic_sidebar( 'kaj-top-sidebar' ); ?>
            </div>
        </div>
        <?php endif; ?>
        

            
        <div class="discovery-single-body">
            <?php
			global $post;
			if ( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					?>
                    <article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                    	<?php if(has_post_thumbnail() && get_the_post_thumbnail() != ''): ?>
                        <div class="discover-image">
                            <div><?php the_post_thumbnail('company-cover'); ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="discover-inner">
                            <header class="entry-header">
                                <?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
                            </header>
                            <div class="entry-content">
                            <?php the_content( );?>
                            </div><!-- .entry-content -->
                        </div><!-- .post-inner -->
					</article><!-- .post -->
					<?php
				}
			}
			?>
        </div><!-- .jobseeker-profile-body -->
        
        </div><!-- .col-md-6,9,12 -->
        <?php if ( is_active_sidebar( 'kaj-right-sidebar' ) ) : ?>
        <div class="col-md-3">
        <?php dynamic_sidebar( 'kaj-right-sidebar' ); ?>
        </div>
        <?php endif; ?>
    </div>
<?php

get_footer();
