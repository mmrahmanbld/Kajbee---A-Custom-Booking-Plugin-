<?php

class KAJBEE_Ajax {

    public $ajax_actions;
    /*
     * Configuring and intializing ajax files and actions
     *
     * @param  -
     * @return -
     */

    public function initialize() {
        $this->configure_actions();
    }

    /*
     * Confire the application specific AJAX actions array and
     * load the AJAX actions bases on supplied parameters
     *
     * @param  -
     * @return -
     */

    public function configure_actions() {

        $this->ajax_actions = array(
			"kajbee_load_home" => array("action" => "kajbee_load_home_action", "function" => "kajbee_load_home_function"),
        );

        /*
         * Add the AJAX actions into WordPress
         */
        foreach ($this->ajax_actions as $custom_key => $custom_action) {

            if (isset($custom_action["logged"]) && $custom_action["logged"]) {
                // Actions for users who are logged in
                add_action("wp_ajax_" . $custom_action['action'], array($this, $custom_action["function"]));
            } else if (isset($custom_action["logged"]) && !$custom_action["logged"]) {
                // Actions for users who are not logged in
                add_action("wp_ajax_nopriv_" . $custom_action['action'], array($this, $custom_action["function"]));
            } else {
                // Actions for users who are logged in and not logged in
                add_action("wp_ajax_nopriv_" . $custom_action['action'], array($this, $custom_action["function"]));
                add_action("wp_ajax_" . $custom_action['action'], array($this, $custom_action["function"]));
            }
        }
    }
		
    /*
     * kajbee_load_home_function for handling AJAX request
     *
     * @param  -
     * @return -
     */

    public function kajbee_load_home_function() {
		header("Content-Type: application/json");
		$content = array();
		$a = &$content;
		$a["home_slider"] = '';
				
		global $wpdb;
		$data = get_option('kajbee_options');
		
		$sliders = !empty($data['home_bg_slider'])?$data['home_bg_slider']:false;
		$a["home_slider"] = $sliders;
		
		echo json_encode($content);
		exit;
    }
		
}

?>