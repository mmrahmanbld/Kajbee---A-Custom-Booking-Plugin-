<?php

class KAJBEE_Script_Controller{
	//public $data;
	
	function __construct(){
		//$this->data = get_option('theme_admin_options');
	}

    public function enque_scripts(){	
	
		add_action('wp_enqueue_scripts', array($this, 'kajbee_scripts_styles'));			
    }
	
	public function kajbee_scripts_styles(){
        global $wp_query;   
		
		wp_register_script('fancybox-js', plugins_url('inc/fancybox/jquery.fancybox.min.js', dirname(__FILE__)), array("jquery"), false, true);
		wp_register_style('fancybox-css', plugins_url('inc/fancybox/jquery.fancybox.min.css', dirname(__FILE__)));
		wp_enqueue_script('fancybox-js');
		wp_enqueue_style('fancybox-css');
		
	}

}

?>