<?php

class KAJBEE_Template_Router {
	
	public $data; 

    public function redirect_templates() {
        add_action('template_redirect', array($this, 'main_router'));
        add_filter('query_vars', array($this, 'manage_routes_query_vars'));
        add_action('init', array($this, 'manage_routing_rules'));
    }

    public function main_router() {

        //$opauth = new KAJBEE_Opauth();
        //$opauth->load_opauth();

        $this->front_controller();

        //$app_theme = new KAJBEE_Theme();
        //$app_theme->application_controller();
		
    }

    public function manage_routes_query_vars($query_vars) {
        $query_vars[] = 'control_action';
        $query_vars[] = 'record_id';

        return $query_vars;
    }

    public function manage_routing_rules() {

        add_rewrite_rule('^user/([^/]+)/([^/]+)/?', 'index.php?control_action=$matches[1]&record_id=$matches[2]', 'top');
        add_rewrite_rule('^user/([^/]+)/?', 'index.php?control_action=$matches[1]', 'top');
		add_rewrite_rule('^hotel/([^/]+)/([^/]+)/?', 'index.php?control_action=$matches[1]&record_id=$matches[2]', 'top');
		add_rewrite_rule('^hotel/([^/]+)/?', 'index.php?control_action=$matches[1]', 'top' );
		add_rewrite_rule('^bus/([^/]+)/([^/]+)/?', 'index.php?control_action=$matches[1]&record_id=$matches[2]', 'top');
		add_rewrite_rule('^bus/([^/]+)/?', 'index.php?control_action=$matches[1]', 'top' );
		add_rewrite_rule('^messages/([^/]+)/([^/]+)/?', 'index.php?control_action=$matches[1]&record_id=$matches[2]', 'top');
		add_rewrite_rule('^messages/([^/]+)/?', 'index.php?control_action=$matches[1]', 'top' );
		
    }

    public function flush_rewriting_rules() {
        $this->manage_routing_rules();
        flush_rewrite_rules();
    }

    public function front_controller() {
        global $wp_query; global $wpdb;
		$this->data = get_option('theme_admin_options');
        $control_action = isset($wp_query->query_vars['control_action'])?$wp_query->query_vars['control_action']:'';

        switch ($control_action) {
            case 'register':
                do_action('kajbee_register_user');
                break;
				
			case 'register-hotel':
                do_action('kajbee_register_hotel');
                break;

            case 'login':
                do_action('kajbee_login_user');
                break;
				
			case 'logout':
                do_action('kajbee_logout_user');
                break;
				
			case 'lost-password':
                do_action('kajbee_user_lost_password');
                break;
			
			case 'reset-password':
                do_action('kajbee_user_reset_password');
                break;
				
            case 'activate':
                do_action('kajbee_activate_user');
                break;
			
            case 'profile':
                $user_name = $wp_query->query_vars['record_id']; 
				if(is_user_logged_in()){             
					$tourist = new KAJBEE_Model_User();
					$info = $tourist->user_basic_info();
					$tmp = new KAJBEE_Template_Loader();
					if($info['user_role'] == 'tourist'){
						$tmp->render("profile", $info);
					}else{
						wp_redirect( home_url() );
					}
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;			
			case 'applicant':
                $tmp = new KAJBEE_Template_Loader();
				$tmp->render("applicant");
                exit;
				break;
			case 'interviewing':
                $tmp = new KAJBEE_Template_Loader();
				$tmp->render("interviewing");
                exit;
				break;
			case 'like':
                $tmp = new KAJBEE_Template_Loader();
				$tmp->render("like");
                exit;
				break;
			case 'hotel-dashboard':
                $user_name = $wp_query->query_vars['record_id'];                
                $company = new KAJBEE_Model_Company($user_name);
                $info = $company->company_basic_info();
                $tmp = new KAJBEE_Template_Loader();
				if($info['user_role'] == 'hotelowner'){
					$tmp->render("hotel-dashboard", $info);
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
			case 'view-hotel':
				$hotel_id = $wp_query->query_vars['record_id']; 
				$app = new KAJBEE_Model_Hotel($hotel_id);
				$info = $app->hotel_basic_info();	
				$tmp = new KAJBEE_Template_Loader();
				$tmp->render("view-hotel", $info);
                exit;
				break;
			case 'edit-hotel':
				if(is_user_logged_in()){								
					$hotel_id = $wp_query->query_vars['record_id']; 
					$app = new KAJBEE_Model_Hotel($hotel_id);
					$info = $app->hotel_basic_info();	
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("edit-hotel", $info);
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
			case 'add-new-hotel':	
				if(is_user_logged_in()){								
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("add-new-hotel", $info);
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
			
			case 'add-new-room':	
				if(is_user_logged_in()){								
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("add-new-room", $info);
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
			case 'edit-room':
				if(is_user_logged_in()){								
					$room_id = $wp_query->query_vars['record_id']; 
					$app = new KAJBEE_Model_Room($room_id);
					$info = $app->room_basic_info();	
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("edit-room", $info);
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;			
			case 'view-room':
				$room_id = $wp_query->query_vars['record_id']; 
				$app = new KAJBEE_Model_Room($room_id);
				$info = $app->room_basic_info();	
				$tmp = new KAJBEE_Template_Loader();
				$tmp->render("view-room", $info);
                exit;
				break;
            case 'room-lists':
				$hotel_id = $wp_query->query_vars['record_id']; 				
				$app = new KAJBEE_Model_Hotel($hotel_id);
				$info = $app->hotel_basic_info();
				
				$tmp = new KAJBEE_Template_Loader();
				$tmp->render("room-lists", $info);
                exit;
				break;
				
			case 'hotel-lists':
				$tmp = new KAJBEE_Template_Loader();
				$tmp->render("hotel-lists");
                exit;
				break;
				
			case 'room-booking':	
				if(is_user_logged_in()){
					$room_id = $wp_query->query_vars['record_id'];
					$app = new KAJBEE_Model_Room($room_id);
					$info = $app->room_basic_info();
				
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("room-booking", $info);
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
					
			case 'payment':	
				if(is_user_logged_in()){								
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("payment");
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
			case 'room-checkout':	
				if(is_user_logged_in()){								
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("room-checkout");
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
				
			case 'checkout':	
				if(is_user_logged_in()){								
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("checkout");
				}else{
					wp_redirect(home_url('/user/login/'));
				}
                exit;
				break;
							
			case 'inbox':
				if(is_user_logged_in()){
					//$user_id = get_current_user_id();
					//$inbox = new KAJBEE_Model_Inbox($user_id);
                	//$info = $inbox->get_inbox_list();
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("inbox", $info);
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
			case 'notifications':
				if(is_user_logged_in()){
					$tmp = new KAJBEE_Template_Loader();
					$tmp->render("notifications", $info);
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
			case 'conversation':
                if(is_user_logged_in()){
					$sender_id = $wp_query->query_vars['record_id'];
					$user_id = get_current_user_id();
					if($sender_id == $user_id){
						wp_redirect( home_url() );
					}else{
						$msg = new KAJBEE_Conversation($sender_id, $user_id);
						$info = $msg->get_conversation();
						
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("conversation", $info);
					}
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
			case 'admin':
                if(is_user_logged_in()){
					$user_id = get_current_user_id();
					$user_info = get_user_by( 'ID', $user_id );
					$user_role = $user_info->roles[0];
					if($user_role == 'administrator' || is_super_admin($user_id)){						
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("admin", $info);
						
					}else{
						wp_redirect( home_url() );
					}
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
			case 'feature':
                if(is_user_logged_in()){
					$user_id = get_current_user_id();
					$user_info = get_user_by( 'ID', $user_id );
					$user_role = $user_info->roles[0];
					if($user_role == 'administrator' || is_super_admin($user_id)){						
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("view-feature-request");
						
					}else{
						wp_redirect( home_url() );
					}
				}else{
					wp_redirect( home_url() );
				}
                exit;
				break;
				
			case 'search':
                $tmp = new KAJBEE_Template_Loader();
                $tmp->render("job-search");
                exit;
				break;
			case 'search-cv':
				if(is_user_logged_in()){
					$user_info = get_user_by( "ID", get_current_user_id() );
					$user_role = $user_info->roles[0];
					if($user_role == 'employer'){
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("search-cv");
					}else{
						wp_redirect( home_url() );
					}
				}else{
					wp_redirect( home_url() );
				}
                exit;
                break;
			case 'feature-job':
                if(is_user_logged_in()){
					$job_id = $wp_query->query_vars['record_id'];
					$user_id = get_current_user_id();
					$user_info = get_user_by( 'ID', $user_id );
					$user_role = $user_info->roles[0];
					if($user_role == 'employer'){
						$job = new KAJBEE_Job_Info($job_id);
                		$info = $job->get_job_info();				
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("feature-job", $info);
						
					}else{
						wp_redirect( home_url( ) );
					}
				}else{
					wp_redirect( home_url( 'user/login' ) );
				}
                exit;
				break;
			case 'feature-apply':
                if(is_user_logged_in()){
					$app_id = $wp_query->query_vars['record_id'];
					$user_id = get_current_user_id();
					$user_info = get_user_by( 'ID', $user_id );
					$user_role = $user_info->roles[0];
					if($user_role == 'jobseeker'){	
						$app = new KAJBEE_Application_Info($app_id);
                		$info = $app->get_apply_info();					
						$tmp = new KAJBEE_Template_Loader();
						$tmp->render("feature-apply", $info);
						
					}else{
						wp_redirect( home_url( ) );
					}
				}else{
					wp_redirect( home_url( 'user/login' ) );
				}
                exit;
				break;
        }
    }

}