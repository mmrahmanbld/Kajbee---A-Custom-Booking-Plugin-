<?php

class KAJBEE_Activation_Controller {

    public function initialize_activation_hooks() {
        register_activation_hook("kajbee/kajbee.php", array($this, 'execute_activation_hooks'));
    }

    public function execute_activation_hooks() {
        //wp_schedule_event(time(), 'everytenminutes', 'notification_sender');


        $this->create_custom_tables();

        $user_manager = new KAJBEE_User_Manager();
        $user_manager->add_application_user_roles();
       //$user_manager->remove_application_user_roles();
        //$user_manager->add_application_user_capabilities();

        $template_router = new KAJBEE_Template_Router();
        $template_router->flush_rewriting_rules();

        
    }
	
	public function create_custom_tables() {
        global $wpdb;
        $table_kaj = $wpdb->base_prefix  . "kaj_lists";
		$table_application = $wpdb->base_prefix  . "kaj_applications";
		$table_apply = $wpdb->base_prefix  . "kaj_apply";
		$table_interview = $wpdb->base_prefix  . "kaj_interview";
		$table_like = $wpdb->base_prefix  . "kaj_like";
		$table_comment = $wpdb->base_prefix  . "kaj_comments";
		
		$table_message = $wpdb->base_prefix  . "kaj_messages";
		$table_notification = $wpdb->base_prefix  . "kaj_notifications";
		
		$table_category = $wpdb->base_prefix  . "kaj_category";
		$table_category_relation = $wpdb->base_prefix  . "kaj_category_relation";
		
		$search_term = $wpdb->base_prefix . "kaj_search_term";
		$search_index = $wpdb->base_prefix . "kaj_search_index";
		
		$table_jobseeker = $wpdb->base_prefix . "kaj_jobseeker";
		$jobseeker_term = $wpdb->base_prefix . "kaj_jobseeker_term";
		$jobseeker_index = $wpdb->base_prefix . "kaj_jobseeker_index";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        $kaj_sql ="CREATE TABLE IF NOT EXISTS $table_kaj (
			kaj_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			company_id bigint(20) UNSIGNED NOT NULL, 
			cat_id bigint(20) UNSIGNED NOT NULL,
			kaj_title varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_responsibility mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL, 
			kaj_education mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_experience mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_skill mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_benefits mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_app_instruction mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_app_method varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_location varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_salary varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_nature varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_level varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			kaj_vacancy smallint(5) UNSIGNED NOT NULL,
			is_featured tinyint(1) UNSIGNED NOT NULL,
			is_feature_request tinyint(1) UNSIGNED NOT NULL,
			feature_request mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			is_approved tinyint(1) UNSIGNED NOT NULL,
			kaj_views bigint(20) UNSIGNED NOT NULL, 
			kaj_likes bigint(20) UNSIGNED NOT NULL,
			kaj_post_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
			kaj_last_date TIMESTAMP NULL,
			PRIMARY KEY (kaj_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";

        $application_sql ="CREATE TABLE IF NOT EXISTS $table_application (
			app_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			kaj_id bigint(20) UNSIGNED NOT NULL, 
			company_id bigint(20) UNSIGNED NOT NULL, 
			jobseeker_id bigint(20) UNSIGNED NOT NULL,
			app_subject varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			app_description mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL, 
			expected_salary varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			is_featured tinyint(1) UNSIGNED NOT NULL,
			is_feature_request tinyint(1) UNSIGNED NOT NULL,
			feature_request mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			is_called tinyint(1) UNSIGNED NOT NULL,
			app_views bigint(20) UNSIGNED NOT NULL,
			app_post_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
			attachment varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			PRIMARY KEY (app_id),
			FOREIGN KEY (kaj_id) 
					REFERENCES $table_kaj(kaj_id)
					ON DELETE CASCADE
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
		
		$apply_sql ="CREATE TABLE IF NOT EXISTS $table_apply (
			apply_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			app_id bigint(20) UNSIGNED NOT NULL, 
			kaj_id bigint(20) UNSIGNED NOT NULL, 
			company_id bigint(20) UNSIGNED NOT NULL, 
			jobseeker_id bigint(20) UNSIGNED NOT NULL,
			PRIMARY KEY (apply_id),
			FOREIGN KEY (kaj_id) 
					REFERENCES $table_kaj(kaj_id)
					ON DELETE CASCADE
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
		
		$interview_sql ="CREATE TABLE IF NOT EXISTS $table_interview (
			interview_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			kaj_id bigint(20) UNSIGNED NOT NULL, 
			company_id bigint(20) UNSIGNED NOT NULL, 
			jobseeker_id bigint(20) UNSIGNED NOT NULL,
			PRIMARY KEY (interview_id),
			FOREIGN KEY (kaj_id) 
					REFERENCES $table_kaj(kaj_id)
					ON DELETE CASCADE
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
		
		$like_sql ="CREATE TABLE IF NOT EXISTS $table_like (
			like_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			kaj_id bigint(20) UNSIGNED NOT NULL, 
			company_id bigint(20) UNSIGNED NOT NULL, 
			jobseeker_id bigint(20) UNSIGNED NOT NULL,
			like_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (like_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
					
		$comment_sql ="CREATE TABLE IF NOT EXISTS $table_comment(
			comment_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			user_id bigint(20) UNSIGNED NOT NULL, 
			comment mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			comment_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
			PRIMARY KEY (comment_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
				
		$message_sql ="CREATE TABLE IF NOT EXISTS $table_message (
			message_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			sender_id bigint(20) UNSIGNED NOT NULL, 
			receiver_id bigint(20) UNSIGNED NOT NULL,
			msg_subject varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			msg_details mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL, 
			msg_read tinyint(1) UNSIGNED NOT NULL,
			msg_read_time TIMESTAMP NULL,
			msg_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
			PRIMARY KEY (message_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
			
		$notification_sql ="CREATE TABLE IF NOT EXISTS $table_notification (
			notify_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			user_id bigint(20) UNSIGNED NOT NULL, 
			sender_id bigint(20) UNSIGNED NOT NULL, 
			notify_title varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			notify_link mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL, 
			notify_read tinyint(1) UNSIGNED NOT NULL,
			notify_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
			PRIMARY KEY (notify_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";	
			
		$category_sql ="CREATE TABLE IF NOT EXISTS $table_category (
			category_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			category_name varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			category_slug varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			PRIMARY KEY (category_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
		
		$category_relation_sql ="CREATE TABLE IF NOT EXISTS $table_category_relation (
			relation_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			kaj_id bigint(20) UNSIGNED NOT NULL, 
			cat_id bigint(20) UNSIGNED NOT NULL, 
			PRIMARY KEY (relation_id),
			FOREIGN KEY (kaj_id) 
					REFERENCES $table_kaj(kaj_id)
					ON DELETE CASCADE
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";
				
		$search_term_sql ="CREATE TABLE IF NOT EXISTS $search_term (
				term_id    bigint(20) UNSIGNED  NOT NULL  AUTO_INCREMENT,
				term_value varchar(255) NOT NULL,
			
				PRIMARY KEY (term_id),
			
				CONSTRAINT UNIQUE (term_value)
			)ENGINE=InnoDB DEFAULT CHARSET=utf8";
			
		$search_index_sql ="CREATE TABLE IF NOT EXISTS $search_index (
				kaj_id   bigint(20) UNSIGNED  NOT NULL,
				term_id  bigint(20) UNSIGNED  NOT NULL,
				offset   bigint(20) UNSIGNED  NOT NULL,
			
				PRIMARY KEY (kaj_id, offset),
			
				FOREIGN KEY (term_id)
					REFERENCES $search_term(term_id),
					
				FOREIGN KEY (kaj_id) 
					REFERENCES $table_kaj(kaj_id)
					ON DELETE CASCADE
       				ON UPDATE CASCADE
			)ENGINE=InnoDB DEFAULT CHARSET=utf8";
		
		$jobseeker_sql ="CREATE TABLE IF NOT EXISTS $table_jobseeker (
			js_id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, 
			user_id bigint(20) UNSIGNED NOT NULL, 
			js_name varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_cur_jobtitle varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_cur_company varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_years_experience varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_last_education varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_marital_status varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_skill mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			js_department varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
			PRIMARY KEY (js_id)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8";

		$jobseeker_term_sql ="CREATE TABLE IF NOT EXISTS $jobseeker_term (
				term_id bigint(20) UNSIGNED  NOT NULL  AUTO_INCREMENT,
				term_value varchar(255) NOT NULL,
				PRIMARY KEY (term_id),
				CONSTRAINT UNIQUE (term_value)
			)ENGINE=InnoDB DEFAULT CHARSET=utf8";
			
		$jobseeker_index_sql ="CREATE TABLE IF NOT EXISTS $jobseeker_index (
				js_id   bigint(20) UNSIGNED  NOT NULL,
				term_id  bigint(20) UNSIGNED  NOT NULL,
				offset   bigint(20) UNSIGNED  NOT NULL,
				PRIMARY KEY (js_id, offset),
				FOREIGN KEY (term_id)
					REFERENCES $jobseeker_term(term_id),
				FOREIGN KEY (js_id) 
					REFERENCES $table_jobseeker(js_id)
					ON DELETE CASCADE
       				ON UPDATE CASCADE
			)ENGINE=InnoDB DEFAULT CHARSET=utf8";
			
		dbDelta($kaj_sql);
		dbDelta($application_sql);
		dbDelta($apply_sql);
		dbDelta($interview_sql);
		dbDelta($like_sql);
		dbDelta($comment_sql);
		dbDelta($message_sql);
		dbDelta($notification_sql);
		dbDelta($category_sql);
		dbDelta($category_relation_sql);

		dbDelta($search_term_sql);
		dbDelta($search_index_sql);
		
		dbDelta($jobseeker_sql);
		dbDelta($jobseeker_term_sql);
		dbDelta($jobseeker_index_sql);
    }
}
?>