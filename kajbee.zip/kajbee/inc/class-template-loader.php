<?php
class KAJBEE_Template_Loader{
	private $template_dir;

	public function __construct(){
		$this->template_dir = "templates";
	}

	public function render($name, $info =  array()){
		include KAJBEE_PATH . $this->template_dir."/".$name.".php";
	}
}


?>
