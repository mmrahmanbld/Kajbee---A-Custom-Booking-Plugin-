<?php
 
class KAJBEE_Paginator {
 
	private $_limit;
	private $_list;
	private $_query;
	private $_total;
	
	public function __construct( $query ) {
     	global $wpdb;
		$this->_query = $query;
		
		$result = $wpdb->get_results($query);
			
		$this->_total = $wpdb->num_rows;
		 
	}
	public function getData( $limit = 10, $list = 1 ) {
		global $wpdb;
		$this->_limit   = $limit;
		$this->_list    = $list;
	 
		if ( $this->_limit == 'all' ) {
			$query      = $this->_query;
		} else {
			$query      = $this->_query . " LIMIT " . ( ( $this->_list - 1 ) * $this->_limit ) . ",". $this->_limit;
		}
	 	$row = $wpdb->get_results($query, ARRAY_A);
			 
		$result         = new stdClass();
		
		$result->list   = $this->_list;
		$result->limit  = $this->_limit;
		$result->total  = $this->_total;
		$result->data   = $row;
		
	 	if(!empty($row)){
			return $result;
		}else{
			return false;
		}
	}
	
	public function createLinks( $links, $query_data = '', $list_class ) {
		if ( $this->_limit == 'all' ) {
			return '';
		}
	 	if(!empty($query_data)){
			$search = '&data='.$query_data;
		}else{
			$search = '';
		}
		$last       = ceil( $this->_total / $this->_limit );
	 
		$start      = ( ( $this->_list - $links ) > 0 ) ? $this->_list - $links : 1;
		$end        = ( ( $this->_list + $links ) < $last ) ? $this->_list + $links : $last;
	 
		$html       = '<ul class="pagination ' . $list_class . '">';
	 
		$class      = ( $this->_list == 1 ) ? "disabled" : "";
		if ( $this->_list == 1 ) {
			$html       .= '<li class="bdr-btn ' . $class . '">&laquo;</li>';
		}else{
			$html       .= '<li><a class="bdr-btn" href="?limit=' . $this->_limit . '&list=' . ( $this->_list - 1 ) .$search. '">&laquo;</a></li>';
		}
		if ( $start > 1 ) {
			$html   .= '<li><a class="bdr-btn" href="?limit=' . $this->_limit . '&list=1'.$search.'">1</a></li>';
			$html   .= '<li class="pagination-dot"><span>...</span></li>';
		}
	 
		for ( $i = $start ; $i <= $end; $i++ ) {
			$class  = ( $this->_list == $i ) ? "active" : "";
			if ( $this->_list == $i ) {
				$html   .= '<li class="bdr-btn ' . $class . '">' . $i . '</li>';
			}else{
				$html   .= '<li><a class="bdr-btn" href="?limit=' . $this->_limit . '&list=' . $i .$search. '">' . $i . '</a></li>';
			}
		}
	 
		if ( $end < $last ) {
			$html   .= '<li class="pagination-dot"><span>...</span></li>';
			$html   .= '<li><a class="bdr-btn" href="?limit=' . $this->_limit . '&list=' . $last .$search. '">' . $last . '</a></li>';
		}
	 
		$class      = ( $this->_list == $last ) ? "disabled" : "";
		if ( $this->_list == $last ) {
			$html       .= '<li class="bdr-btn ' . $class . '">&raquo;</li>';
		}else{
			$html       .= '<li><a class="bdr-btn" href="?limit=' . $this->_limit . '&list=' . ( $this->_list + 1 ) .$search. '">&raquo;</a></li>';
		}
		$html       .= '</ul>';
	 
		return $html;
	}

 
}