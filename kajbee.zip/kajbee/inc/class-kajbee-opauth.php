<?php


class KAJBEE_Opauth {

    public function __construct() {

    }

    public function initialize() {
		add_action('template_redirect', array($this, 'load_kajbee_opauth'));
        //add_action('kajbee_login_addons', array($this, 'login_addons'));
    }



    public function login_addons() {
        echo '<a href="facebook">Facebook</a>
              <a href="twitter">Twitter</a>
              <a href="linkedin">LinkedIn</a>
			  <a href="google">Google</a>
           ';
    }

    public function load_kajbee_opauth() {
        global $wp;

		if ($wp->request == 'opauth_success' && isset( $_GET['social_action'])) {
			
			$social_username = '';
			$social_first_name = '';
			$social_email = '';
			$social_message ='';
			$response = null;
			$path = ''; $callback = '';
			
			if($_GET['social_action'] == 'register'){
				$path = '/user/register/';
				$callback = '/opauth_success/?social_action=register';
			}elseif($_GET['social_action'] == 'login'){
				$path = '/user/login/';
				$callback = '/opauth_success/?social_action=login';
			}
			
			$config = kajbee_opauth($path, $callback);
			
			require KAJBEE_PATH.'inc/lib/Opauth/Opauth.php';
			$Opauth = new Opauth( $config );
		
			switch ($Opauth->env['callback_transport']) {
				case 'session':
					session_start();
					$response = $_SESSION['opauth'];
					unset($_SESSION['opauth']);
					break;
				case 'post':
					$response = unserialize(base64_decode($_POST['opauth']));
					break;
				case 'get':
					$response = unserialize(base64_decode($_GET['opauth']));
					break;
				default:
					$social_message = '<div class="mb-15 kaj-danger"><strong style="color: red;">Error: </strong>Unsupported callback_transport.' . "</div>";
					break;
			}
		
			$provider = isset($response['auth']['provider']) ? $response['auth']['provider'] : '';
			$user_info = $response['auth']['info'];
		
			switch ($provider) {
				case 'Facebook':
					$s_email = explode("@", $user_info['email']);
					$social_email = $user_info['email'];
					$social_nickname = $user_info['username'];
					$social_name = $user_info['name'];
					$fb_nickname = str_replace( ' ', '', $social_name );
					if($social_email){
						$social_username = $s_email[0];
						$social_email = $user_info['email'];
					}elseif($social_nickname){
						$social_username = $social_nickname;
						$social_email = '';
					}else{
						$social_username = $fb_nickname;
						$social_email = '';
					}
					
					break;
				case 'Twitter':
					$social_username = $user_info['nickname'];
					$social_first_name = $user_info['name'];
					$social_email = $user_info['email'];
					break;
				case 'LinkedIn':
					$s_email = explode("@", $user_info['email']);
					$social_username = $s_email[0];
					$social_first_name = $user_info['name'];
					$social_email = $user_info['email'];
					break;
				case 'Google':
					$s_email = explode("@", $user_info['email']);
					$social_username = $s_email[0];
					$social_first_name = $user_info['name'];
					$social_email = $user_info['email'];
					break;
			}
			
			
			switch ($_GET['social_action']) {	
				case 'register':
					if(username_exists($social_username)) {
						$social_message = '<div class="mb-15 kaj-danger"><strong style="color: red;">Error: </strong>Username already exists. Please try another.' . "</div>";				
					}elseif(email_exists($social_email)) {
						$social_message = '<div class="mb-15 kaj-danger"><strong style="color: red;">Error: </strong>Email address already exists. Please try another.' . "</div>";				
					}else{
						$social_message = '<div class="mb-15 kaj-success">Please fill up below field and select user type below. <span class="text-success">Social registration does not require email verification.</span>' . "</div>";
					}
					include KAJBEE_PATH . 'templates/register.php';
					exit;
					break;
								
				case 'login':
					$errors = array();
					if (username_exists($social_username)) {
						$user = get_user_by('login', $social_username);
						wp_set_auth_cookie($user->ID, false, is_ssl());
						if($user->roles[0] == 'employer'){
							wp_redirect( home_url('/company/directory/'.$user->user_login) );
						}elseif($user->roles[0] == 'jobseeker'){
							wp_redirect( home_url('/jobseeker/profile/'.$user->user_login) );
						}else{
							wp_redirect( home_url() );
						}
					} else {
						array_push( $errors, 'User name with this social id does not exists.' );
						include KAJBEE_PATH . 'templates/login.php';
				    	exit;
					}
					
					break;
				
			}
		}
		
    }



}

