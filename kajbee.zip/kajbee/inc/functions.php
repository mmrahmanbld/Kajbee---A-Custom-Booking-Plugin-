<?php


function kajbee_slugify($text){
	// replace non letter or digits by -
	$text = preg_replace('~[^\pL\d]+~u', '-', $text);
	// transliterate
	$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
	// remove unwanted characters
	$text = preg_replace('~[^-\w]+~', '', $text);
	// trim
	$text = trim($text, '-');
	// remove duplicate -
	$text = preg_replace('~-+~', '-', $text);
	// lowercase
	$text = strtolower($text);
	if (empty($text)) {
	return 'n-a';
	}
	return $text;
}
function kajbee_rnt($text){
	return str_replace(array("\rn", "\r", "\n", "\t", "\v"), '', $text);
}
function kajbee_br($string){
	return preg_replace("/<br\W*?\/>/", "\n", $string);
}
function kajbee_mail_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','kajbee_mail_set_content_type' );

function kajbee_media_handle_upload($file_handler, $post_id) {
	if ($_FILES[$file_handler]['error'] !== UPLOAD_ERR_OK) __return_false();
	require_once(ABSPATH . "wp-admin" . '/includes/image.php');
  	require_once(ABSPATH . "wp-admin" . '/includes/file.php');
  	require_once(ABSPATH . "wp-admin" . '/includes/media.php');
	
	$attach_id = media_handle_upload( $file_handler, $post_id );
	if ( is_numeric( $attach_id ) ) {
		return $attach_id;
	}else{
	  return false;
	}

}

function kajbee_cut_content($post_content, $limit = 20, $strip_html = true) {

	if($strip_html) {
		$raw_content = strip_shortcodes( strip_tags( html_entity_decode($post_content) ) );
	} else {
		$raw_content = strip_shortcodes( $post_content );
	}

	if($raw_content) {
		$content = explode(' ', $raw_content, $limit);
		if (count($content)>=$limit) {
			array_pop($content);
			$content = implode(" ",$content).' ... ';
		} else {
			$content = implode(" ",$content);
		}	
		$content = preg_replace('/\[.+\]/','', $content);
		$content = str_replace(']]>', ']]&gt;', $content);
		return $content;
	}
}

function get_kajbee_pagination($pages = '', $range = 3){
	 $html = '';

	$showitems = ($range * 2)+1;
	if(is_front_page() ) {
		$paged = (get_query_var('page')) ? get_query_var('page') : 1;
	} else {
		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	}
	if(empty($paged)) $paged = 1;

	 if($pages == '') {
		 global $wp_query;
		 $pages = $wp_query->max_num_pages;
		 if(!$pages) {
			 $pages = 1;
		 }
	 }

	 if(1 != $pages) {
		 $html .= '<div class="pagination clearfix"><nav class="navigation pagination" role="navigation"><div class="nav-links">';
		 if($paged > 1) $html .= '<a class="prev page-numbers" href="'.get_pagenum_link($paged - 1).'"><span class="page-prev"></span>&larr; Previous</a>';

		 for ($i=1; $i <= $pages; $i++) {
			 if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
				if ($paged == $i) {
					$html .= '<span class="page-numbers current">'.$i.'</span>';
				} else {
					$html .= '<a href="'.get_pagenum_link($i).'" class="page-numbers inactive" >'.$i.'</a>';
				}
			 }
		 }

		 if ($paged < $pages) $html .= '<a class="next page-numbers " href="'.get_pagenum_link($paged + 1).'">Next &rarr;<span class="page-next"></span></a>';
		 $html .= '</div></nav></div>';
	 }
	return $html;
}

function kajbee_date($str_date){
	$time = strtotime($str_date);
	$newformat = date('M d, Y',$time);
	return $newformat;
}
function kajbee_num_date($str_date){
	$time = strtotime($str_date);
	$newformat = date('d-m-y',$time);
	return $newformat;
}

function kajbee_isodate($str_date){
	$time = strtotime($str_date);
	$newformat = date('Y-m-d',$time);
	return $newformat;
}

function kajbee_today(){
	$time = strtotime('today');
	$today = date('M d, Y',$time);
	return $today;
}

function kajbee_countdays($days){
	$from = strtotime($days);
	$today = time();
	$difference = $from - $today;
	return floor($difference / 86400);
}

function kajbee_filename ($uri) {
    if (empty($uri)) return false;
    $parts = explode('/', $uri);
    return array_pop($parts);
}  

add_filter( 'get_avatar' , 'kajbee_user_avatar' , 10, 5 );
/**
 * Retrieve the local avatar for a user who provided a user ID or email address.
 *
 * @param string $avatar Avatar return by original function
 * @param int|string|object $id_or_email A user ID,  email address, or comment object
 * @param int $size Size of the avatar image
 * @param string $default URL to a default image to use if no avatar is available
 * @param string $alt Alternative text to use in image tag. Defaults to blank
 * @return string <img> tag for the user's avatar
 */
function kajbee_user_avatar(  $avatar, $id_or_email, $size='32', $default, $alt = '' ) {
    $user = false;

    if ( is_numeric( $id_or_email ) ) {

        $id = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
    } elseif ( is_object( $id_or_email ) ) {

        if ( ! empty( $id_or_email->user_id ) ) {
            $id = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }

    } else {
        $user = get_user_by( 'email', $id_or_email );	
    }

    if ( $user && is_object( $user ) ) {
		$user_meta = get_user_meta( $user->ID);
		$alt = $user->user_name;
		$avatar_uri = isset($user_meta['kajbee_user_avatar'][0])?$user_meta['kajbee_user_avatar'][0]:'';  
		if(!empty($avatar_uri)){          
        	$avatar = "<img alt='{$alt}' src='{$avatar_uri}' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
		}
    }

    return $avatar;
}
function kajbee_age($dob){
	$from = new DateTime($dob);
	$to   = new DateTime('today');
	return $from->diff($to)->y;
}

function kajbee_opauth($path, $callback){
	
	$data = get_option('theme_admin_options'); 
	
	$fb_id = $data['facebook_app_id']?$data['facebook_app_id']:'';
	$fb_secret = $data['facebook_app_secret']?$data['facebook_app_secret']:'';
	$tw_id = $data['twitter_app_key']?$data['twitter_app_key']:'';
	$tw_secret = $data['twitter_app_secret']?$data['twitter_app_secret']:'';
	$ln_id = $data['linkedin_api_key']?$data['linkedin_api_key']:'';
	$ln_secret = $data['linkedin_secret_key']?$data['linkedin_secret_key']:'';
	$go_id = $data['google_client_id']?$data['google_client_id']:'';
	$go_secret = $data['google_client_secret']?$data['google_client_secret']:'';
	
	$config = array(
		'path' => $path,
		'callback_url' => $callback,
		'security_salt' => 'kajbeejobapplicationwordpresstheme',
		'Strategy' => array(
			'Facebook' => array(
				'app_id' => $fb_id,
				'app_secret' => $fb_secret
			),
			'Twitter' => array(
				'key' => $tw_id,
				'secret' => $tw_secret
			),
			'LinkedIn' => array(
				'api_key' => $ln_id,
				'secret_key' => $ln_secret
			),
			'Google' => array(
				'client_id' => $go_id,
				'client_secret' => $go_secret
			),
		),
	);
	
	return $config;
}

function kajbee_seen_at($created_time){
        date_default_timezone_set('asia/dhaka'); //Change as per your default time
        $str = strtotime($created_time);
        $today = strtotime(date('Y-m-d H:i:s'));//date('Y-m-d',strtotime('today'));
        // It returns the time difference in Seconds...
        $time_differnce = $today-$str;
        // To Calculate the time difference in Years...
        $years = 60*60*24*365;
        // To Calculate the time difference in Months...
        $months = 60*60*24*30;
        // To Calculate the time difference in Days...
        $days = 60*60*24;
        // To Calculate the time difference in Hours...
        $hours = 60*60;
        // To Calculate the time difference in Minutes...
        $minutes = 60;
        if(intval($time_differnce/$years) > 1){
            return intval($time_differnce/$years)." years ago";
        }else if(intval($time_differnce/$years) > 0){
            return intval($time_differnce/$years)." year ago";
        }else if(intval($time_differnce/$months) > 1){
            return intval($time_differnce/$months)." months ago";
        }else if(intval(($time_differnce/$months)) > 0){
            return intval(($time_differnce/$months))." month ago";
        }else if(intval(($time_differnce/$days)) > 1){
            return intval(($time_differnce/$days))." days ago";
        }else if (intval(($time_differnce/$days)) > 0){
            return intval(($time_differnce/$days))." day ago";
        }else if (intval(($time_differnce/$hours)) > 1){
            return intval(($time_differnce/$hours))." hours ago";
        }else if (intval(($time_differnce/$hours)) > 0){
            return intval(($time_differnce/$hours))." hour ago";
        }else if (intval(($time_differnce/$minutes)) > 1){
            return intval(($time_differnce/$minutes))." minutes ago";
        }else if (intval(($time_differnce/$minutes)) > 0){
            return intval(($time_differnce/$minutes))." minute ago";
        }else if (intval(($time_differnce)) > 1){
            return intval(($time_differnce))." seconds ago";
        }else{
            return "few seconds ago";
        }
  }

function kajbee_register_page_redirect(){
	global $pagenow;
	if ( ( strtolower($pagenow) == 'wp-login.php') && ( strtolower( $_GET['action']) == 'register' ) ) {
		wp_redirect( home_url('/user/register'));
		exit;
	}
}

add_filter( 'init', 'kajbee_register_page_redirect' );