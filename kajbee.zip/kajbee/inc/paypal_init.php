<?php

$data = get_option('theme_admin_options');
$kaj_clientId = $data['kaj_paypal_clientid'];
$kaj_clientSecret = $data['kaj_paypal_clientsecret'];

$paypal = new PayPal\Rest\ApiContext(
			new PayPal\Auth\OAuthTokenCredential(
				$kaj_clientId,
				$kaj_clientSecret
			)
		);