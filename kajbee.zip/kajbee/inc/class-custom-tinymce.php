<?php
class KAJBEE_TinyMCE_Loader{

	public function __construct(){
		add_action( 'init', array($this, 'kajbee_tinymce_buttons') );
	}

	
	public function kajbee_tinymce_buttons() {
		add_filter( "mce_external_plugins", array($this, "kajbee_add_tinymce_buttons") );
		add_filter( 'mce_buttons_2', array($this, 'kajbee_register_tinymce_buttons') );
	}
	public function kajbee_add_tinymce_buttons( $plugin_array ) {
		$plugin_array['kajbutton'] = KAJBEE_URL . 'js/tinymce/tinymce-plugin.js';
		return $plugin_array;
	}
	public function kajbee_register_tinymce_buttons( $buttons ) {
		array_push( $buttons, 'kajbutton' ); // dropcap', 'recentposts
		return $buttons;
	}
}



?>