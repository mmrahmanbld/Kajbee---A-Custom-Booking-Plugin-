<?php


class KAJBEE_Shortcode_Loader{

	public function __construct(){
				
		add_filter('the_content', array($this, 'kajbee_shortcodes_formatter'));
		add_filter('widget_text', array($this, 'kajbee_shortcodes_formatter'));
		add_filter('widget_text', 'do_shortcode');
		
		add_shortcode('kajbee_seearch_box', array($this, 'shortcode_kajbee_seearch_box'));
		add_shortcode('kajbee_category', array($this, 'shortcode_kajbee_category'));
		add_shortcode('kajbee_category_widget', array($this, 'shortcode_kajbee_category_widget'));
		add_shortcode('discover_places', array($this, 'shortcode_discover_places'));
		add_shortcode('tabmenu', array($this, 'shortcode_tabmenu'));
		add_shortcode('tab_content_wrap', array($this, 'shortcode_tab_content_wrap'));
		add_shortcode('tab_content', array($this, 'shortcode_tab_content'));
		add_shortcode('accordion', array($this, 'shortcode_accordion'));
		add_shortcode('collapse', array($this, 'shortcode_collapse'));
	}

	public function kajbee_shortcodes_formatter($content) {
		$block = join("|",array("kajbee_seearch_box", "discover_places", "tabs_container","tabmenu_wrap"));
		// opening tag
		$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		// closing tag
		$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)/","[/$2]",$rep);
		return $rep;
	}
	
	//////////////////////////////////////////////////////////////////
	// Check list shortcode
	//////////////////////////////////////////////////////////////////

	public function shortcode_kajbee_seearch_box( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'location' => false,
			'category' => false,
		), $atts));
		
		if($location && $category){
			$col_class = 'col-md-5 col-sm-5';
		}elseif($location || $category){
			$col_class = 'col-md-7 col-sm-7';
		}else{
			$col_class = 'col-md-10 col-sm-10';
		}
	
		$html = '';
		$html .= '<div class="kajbee-search-box row m-zero">';
		$html .= '<form class="kajbee-search-form pd-15 rds allopbgc_50 kaj-trans-bdr block clearfix" method="post" action="'.get_site_url().'/jobs/search">';
		$html .= '<div class="col-md-9 col-sm-9 p-zero">';
		$html .= '<input class="kajbee-search-text mr-5" name="kajbee_search_query" id="kajbee_search_query" required="required" placeholder="Where are you going?" value="" type="text">';	
		$html .= '</div>';
		$html .= '<div class="col-md-3 col-sm-3 p-zero">';
		$html .= '<input type="submit" name="kajbee_submit_search" class="btn btn-block" value="Search">';
		$html .= '</div>';
		$html .= '</form>';
		$html .= '</div>';
		return $html;
	}


	public function shortcode_kajbee_category( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'columns' => 3,
			'iconcolor' => '',
			'style' => '',
			'class' => '',
		), $atts));
		
		if($columns == 4){
			$cols = 'col-md-3 col-sm-3 col-xs-12';
		}elseif($columns == 2){
			$cols = 'col-md-6 col-sm-6 col-xs-12';
		}else{
			$cols = 'col-md-4 col-sm-4 col-xs-12';
		}		
		$cat = new KAJBEE_Model_Category();
		$cat_init = $cat->category_init();
		
		$category = $cat->get_category_list();
		
		$html = '';
		$html .= '<div class="job-category-list wbgc rds kaj-bdr mt-15 mb-15">';
		$html .= '<h4 data-event="kaj-toggle-category" class="pd-10 kaj-color uppercase m-zero"><i class="fa fa-list-ul"></i>&nbsp;'.__('Job Category', THEMENAME).'<span class="visible-xs-inline-block pull-right"><i class="fa fa-caret-down"></i></span></h4>';
		$html .= '<div id="kaj_top_job_category">';
		$html .= '<div class="pd-10 row m-zero">';
		foreach($category as $key => $val){
			$html .= '<div class="'.$cols.' p-zero"><a href="'.get_site_url().'/jobs/category/?data='.$key.'" target="_blank"><i class="fa fa-caret-right"></i>&nbsp;'.$val->category_name.' <span>('.$val->category_no.')</span></a></div>';
		}
		$html .= '</div>';
		$html .= '</div>';
		$html .= '</div>';
		
		return $html;
		
	}
	public function shortcode_kajbee_category_widget( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'class' => '',
		), $atts));
		
		$cat = new KAJBEE_Model_Category();
		$cat_init = $cat->category_init();
		
		$category = $cat->get_category_list();
		
		$html = '';
		$html .= '<div class="job-category-list p-zero">';
		$html .= '<h4 class="kaj-color uppercase m-zero"><i class="fa fa-list-ul"></i>&nbsp;'.__('Job Category', THEMENAME).'</h4>';
		$html .= '<div class="row m-zero p-zero">';
		foreach($category as $key => $val){
			$html .= '<div class="col-md-12 p-zero"><a href="'.get_site_url().'/jobs/category/?data='.$key.'" target="_blank"><i class="fa fa-caret-right"></i>&nbsp;'.$val->category_name.' <span>('.$val->category_no.')</span></a></div>';
		}
		$html .= '</div>';
		$html .= '</div>';
		
		return $html;
		
	}
	
	public function shortcode_discover_places( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'columns' => 1,
			'load' => 20,
		), $atts));
		
		$cols = 'col-md-12';
		$col_nos = 1;
		$col_class = ' kaj_one_cols';
		
		$html = '';
		
		
				
		if(is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}


		$args = array(
			'post_type' => 'discover',
			'paged' => $paged,
			'posts_per_page' => 20,
		);
		
		if((isset($_GET['discover_places']) && $_GET['discover_places'] != '')){
			$args['tax_query'] = array(
				'relation' => 'AND',
				array(
					'taxonomy' => 'discover_places',
					'field' => 'slug',
					'terms' => kajbee_slugify($_GET['discover_places'])
				)
			);
		}
		
		if(isset($_GET['discover_event_types']) && $_GET['discover_event_types'] != ''){
			if(isset($_GET['hotel_amenities']) && count($_GET['hotel_amenities']) > 0){
				foreach ($_GET['hotel_amenities'] as $key => $val){
					$amenities['key'] = $val;
					$amenities['value'] = 'Yes';
				};
			}
			$args['meta_query'] = array(
				'relation' => 'AND',
				'key' => 'discover_event_types',
				'value' => $_GET['discover_event_types'],
			);
			
		}
		
		$query = new WP_Query($args);
		
		$html .= '<div class="discovery-search-box row">';
			$html .= '<div class="search-box clearfix">';
			$html .= '<form method="get" id="search-form discover-search-form color-t75" action="" >';
				$html .= '<div class="col-md-9 col-sm-9 col-xs-9 autocomplete">';
					$html .= '<input id="discover_places" type="text" name="discover_places" placeholder="Discover places by location" value=""/>';
				$html .= '</div>';
				$html .= '<div class="col-md-3 col-sm-3 col-xs-3">';
					$html .= '<input id="submit" class="button btn" name="submitted" type="submit" tabindex="3" value="Search" />	';				
				$html .= '</div>';
			$html .= '</form>';
		$html .= '</div>';
		$html .= '</div>';
		/*
		$html .= '<div class="discovery-filter-box row  p-zero m-zero">';
			$html .= '<form method="get" id="search-form" action="'. isset($_SERVER["QUERY_STRING"]) ? $_SERVER["QUERY_STRING"] : "".'" >';
			  	$html .= '<div class="col-md-9 col-sm-9 col-xs-9 p-zero m-zero">';
					  $html .= '<input type="checkbox" name="discover_event_types[]" value="0-999">0 - 999<br/>';
					  $html .= '<input type="checkbox" name="discover_event_types[]" value="1000-2999">1000 - 2999<br/>';
					  $html .= '<input type="checkbox" name="discover_event_types[]" value="3000-4999">3000 - 4999<br/>';
				$html .= '</div>';                   
				$html .= '<div class="col-md-3 col-sm-3 col-xs-3 p-zero m-zero">';
					$html .= '<input id="submit" class="button btn" name="submitted" type="submit" tabindex="3" value="Filter" />';				
			  	$html .= '</div>';
			$html .= '</form>';
		$html .= '</div>';
		*/
		if($query->have_posts()){
			$html .= '<div class="discovery_wrap ptb-60">';
			if((isset($_GET['discover_places']) && $_GET['discover_places'] != '')){
			$html .= '<h3 class="discovery-place-name mb-30 mt-5">Recommended in '.$_GET['discover_places']. '</h3>';
			}
			while($query->have_posts()): $query->the_post();
				$permalink = get_permalink(get_the_ID());
				$html .= '<div class="row m-zero p-zero'.$col_class.'">';
					$html .= '<div class="wbgc shadow mb-30 clearfix">';
						$html .= '<div class="col-md-5 col-sm-5 p-zero m-zero">';
							$html .= '<div class="discovery-img">';
							if(has_post_thumbnail( get_the_ID() )){
							$src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'trip-gallery' );
							$large = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'large' );
							$html .= '<a data-fancybox="gallery" href="'.$large[0].'"><img src="'.$src[0].'"></a>';
							}
							$html .= '</div>';
						$html .= '</div>';
						
						$html .= '<div class="col-md-7 col-sm-7 p-zero">';
							$html .= '<div class="row p-zero m-zero">';
								$html .= '<div class="col-md-9 col-sm-9 col-xs-9 p-zero m-zero">';
									$html .= '<div class="pl-30 discover-info">';
									$html .= '<h3>' . get_the_title(get_the_ID()) . '</h3>';
									$html .= '<p>' . kajbee_cut_content( get_the_content(get_the_ID())) . '</p>';
									$html .= '</div>';
								$html .= '</div>';
								$html .= '<div class="col-md-3 col-sm-3 col-xs-3 p-zero m-zero">';
								$event_types = get_post_meta(get_the_ID(), "discover_event_types", true)?get_post_meta(get_the_ID(), "discover_event_types", true):'';
								$html .= '<div class="pr-30 pt-20 text-right">';
								if($event_types == 'Festival'){
									$html .= '<img src="'.KAJBEE_URL . 'images/festival.png">';
								}elseif($event_types == 'Places'){
									$html .= '<img src="'.KAJBEE_URL . 'images/place.png">';
								}else{
									$html .= '<img src="'.KAJBEE_URL . 'images/tour.png">';
								}
								$html .= '</div>';
								$html .= '</div>';
							$html .= '</div>';
							$html .= '<div class="row p-zero m-zero">';
								$html .= '<div class="pl-30 clearfix mt-30">';
									$html .= '<div class="col-md-6 col-sm-6 col-xs-6 p-zero m-zero">';
									$html .= '<div><a class="discover-more" href="'.$permalink.'"><span><i class="fa fa-angle-right"></i></span>&nbsp;&nbsp;Learn more</a></div>';
									$html .= '</div>';
									$html .= '<div class="col-md-6 col-sm-6 col-xs-6 p-zero m-zero">';
									$html .= '<div class="discover-price">';
									$html .= get_post_meta(get_the_ID(), "discover_price_starts", true)?'Tk '.get_post_meta(get_the_ID(), "discover_price_starts", true):'';
									$html .= '</div>';
								$html .= '</div>';
							$html .= '</div>';
						$html .= '</div>';
					$html .= '</div>';
				$html .= '</div>';
			endwhile;
			$html .= '</div>';
			$html .= get_kajbee_pagination($query->max_num_pages, $range = 6);
		}else{
			$html .= '<div class="row mt-30 mb-30">';
				$html .= '<div class="col-md-12">';
					$html .= '<div class="page-content text-center error-404 not-found">';
						$html .= '<h3 class="eoops">Oops, No place Found!</h3>';
					$html .= '</div>';
				$html .= '</div>';
			$html .= '</div>';
		}
		
		return $html;
		
	}
	
	public function shortcode_kajbee_feature_jobs( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'icon' => '',
			'iconcolor' => '',
			'style' => '',
			'class' => '',
		), $atts));
				
		$cat = new KAJBEE_Model_Category();
		$cat_init = $cat->category_init();
		
		$category = $cat->get_category_list();
		
		$html = '';
		$html .= '<div class="row">';
		$html .= '<div class="job-category-list">';
		foreach($category as $key => $val){
			$html .= '<div class="col-md-4 col-sm-4  col-xs-6"><a href="'.get_site_url().'/jobs/category/?data='.$key.'" target="_blank">'.$val->category_name.' <span>('.$val->category_no.')</span></a></div>';
		}
		$html .= '</div>';
		$html .= '</div>';
		
		return $html;
		
	}

	//////////////////////////////////////////////////////////////////
	// Tabs shortcode
	//////////////////////////////////////////////////////////////////

	public function shortcode_tabs_container( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'bgcolor' => '',
			'bordercolor' => '',
			'border' => '',
			'style' => '',
			'mode' => 'horizontal',
		), $atts));
		
		// List numbers 1 to 1000
		$id = range(1,1000);
		shuffle($id);
		// Get an id
		$id = array_shift($id);
		
		$html .='<div id="tabs-'.$id.'" class="fone-tabs">';
		$html .=do_shortcode($content);
		$html .='</div>';
		$html .= '<script>
				(function($){
					$(document).ready(function () {
						$("#tabs-'.$id.' .bxslider").bxSlider({
							pagerCustom: ".tabs-pager",
							hideControlOnEnd : true,
							auto : false,
							pager : true,
							controls : false,
							infiniteLoop: true,
							mode : '.$mode.',
						});
					});
				})(jQuery);
			</script>';
	
		return $html;
	}
	

	public function shortcode_tabmenu_wrap( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'position' => 'left',
			'title' => '',
		), $atts));
	
		$html = '';
		$html .= '<div class="row">';
		$html .= '<div class="tabs-pager tabs-'.$position.'">';	
		$html .=do_shortcode($content);
		$html .= '</div>';
		$html .= '</div>';
		return $html;
	}


	public function shortcode_tabmenu( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'index' => '',
			'icon' => '',
		), $atts));
	
		$html = '';
		$html .= '<a data-slide-index="'.$index.'" href=""><i class="fa fa-'.$icon.'"></i></a>';
		return $html;
	}

	public function shortcode_tab_content_wrap( $atts, $content = null ) {
	
		$html = '';
		$html .= '<ul class="bxslider">';
		$html .=do_shortcode($content);
		$html .= '</ul>';
		return $html;
	}
	
	
	public function shortcode_tab_content( $atts, $content = null ) {
		$html = '';
		$html .= '<li>';
		$html .=do_shortcode($content);
		$html .= '</li>';
		return $html;
	}

	//////////////////////////////////////////////////////////////////
	// accordion
	//////////////////////////////////////////////////////////////////

	public function shortcode_accordion( $atts, $content = null ) {
		$html = '';
		$html .= '<div class="accordion">';
		$html .= do_shortcode($content);
		$html .= '</div>';
		
	   return $html;
	}	


	public function shortcode_collapse( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => '',
		), $atts));
		// List numbers 1 to 1000
		$id = range(1,1000);
		shuffle($id);
		// Get an id
		$id = array_shift($id);
		$html = '';
		$html .= '<div class="accordion-section">';
		$html .= '<a class="accordion-section-title" href="#accordion-'.$id.'">'.$title.'<span class="accordion-item-arrow"></span></a>';
		$html .= '<div id="accordion-'.$id.'" class="accordion-section-content">';
		$html .= do_shortcode($content);
		$html .= '</div></div>';
		
	   return $html;
	}

}

new KAJBEE_Shortcode_Loader();

	
